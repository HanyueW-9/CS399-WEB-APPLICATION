<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <style type="text/css">
        #d1{
         font-family: Comic Sans MS;
         position:absolute;
         left:14px;
         top:32px;
         font-size: 12px;
        }
        #input1{
         font-family: Comic Sans MS;
         width:200px;
         height:25px;
         position:absolute;
         left:93px;
         top:27px;
         font-size: 12px;
         border:1px solid #000;
        }
        #d2{
         font-family: Comic Sans MS;
         position:absolute;
         left:16px;
         top:68px;
         font-size: 12px;
        }
        #input2{
         font-family: Comic Sans MS;
         width:200px;
         height:25px;
         position:absolute;
         left:95px;
         top:63px;
         font-size: 12px;
         border:1px solid #000;
        }
        #d3{
         font-family: Comic Sans MS;
         position:absolute;
         left:14px;
         top:100px;
         font-size: 12px;
        }
        #input3{
         font-family: Comic Sans MS;
         width:200px;
         height:25px;
         position:absolute;
         left:97px;
         top:100px;
         font-size: 12px;
         border:1px solid #000;
        }
        #d4{
         font-family: Comic Sans MS;
         position:absolute;
         left:14px;
         top:130px;
         font-size: 12px;
        }
        #input4{
         font-family: Comic Sans MS;
         width:200px;
         height:25px;
         position:absolute;
         left:95px;
         top:125px;
         font-size: 12px;
         border:1px solid #000;
        }
        #btn1{
         font-family: Comic Sans MS;
         position:absolute;
         left:85px;
         top:188px;
         font-size: 12px;
         width: 90px;
         height: 25px;
         background-color: #c0c1bd;
         border:1px solid #000;
        }
        #btn2{
         font-family: Comic Sans MS;
         position:absolute;
         left:207px;
         top:188px;
         font-size: 12px;
         width: 90px;
         height: 25px;
         background-color: #c0c1bd;
         border:1px solid #000;
        }
    </style>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
     <form action="/demo/demo_form.asp">
     <div id="d1">Item: </div> <input id="input1" type="text" name="Item" >
     <br>
     <div id="d2">Production: </div> <input id="input2" type="text" name="Production" >
     <br>
     <div id="d3">Origin: </div> 
     <select id="input3"  name="Origin">
     <option selected value="Flagstaff" selected="selected">Flagstaff</option>
     <option value="Phoenix">Phoenix</option>
     <option value="New York">New York</option>
     </select>
     <br>
     <div id="d4">Price: </div> <input id="input4" type="text" name="Price" >
     <br>
     <input id="btn1" type="submit" value="Save">
     <input id="btn2" type="submit" value="Cancle">
     </form> 

    </body>
</html>