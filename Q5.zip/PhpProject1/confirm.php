<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <style type="text/css">
        #div1{
         font-family: Comic Sans MS;
         position:absolute;
         left:6px;
         top:46px;
         font-size: 12px;
        }
        #div2{
         font-family: Comic Sans MS;
         position:absolute;
         left:69px;
         top:46px;
         font-size: 12px;
        }
        #btn1{
         font-family: Comic Sans MS;
         position:absolute;
         left:4px;
         top:90px;
         font-size: 12px;
         width: 90px;
         height: 25px;
         background-color: #c0c1bd;
         border:1px solid #000;
        }
        #btn2{
         font-family: Comic Sans MS;
         position:absolute;
         left:109px;
         top:90px;
         font-size: 12px;
         width: 90px;
         height: 25px;
         background-color: #c0c1bd;
         border:1px solid #000;
        }
    </style>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div id="div1">Removing:</div>
        <div id="div2">Rice</div>
        <input id="btn1" type="submit" value="Confirm">
        <input id="btn2" type="submit" value="Cancle">
    </body>
</html>