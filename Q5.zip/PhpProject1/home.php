<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <style type="text/css">
    #div1{
         font-family: Comic Sans MS;
         width:171px;
         height:170px;
         border:1px solid #000;
         background:transparent;
         overflow-y: scroll;
         position:absolute;
         left:21px;
         top:16px;
         font-size: 12px;
     }
     #btn1{
         font-family: Comic Sans MS;
         width: 90px;
         height: 25px;
         border:1px solid #000;
         background-color: #c0c1bd;
         position:absolute;
         left:227px;
         top:16px;
         font-size: 12px;
     }
     #btn2{
         font-family: Comic Sans MS;
         width: 90px;
         height: 25px;
         border:1px solid #000;
         background-color: #c0c1bd;
         position:absolute;
         left:226px;
         top:79px;
         font-size: 12px;
     }
     #btn3{
         font-family: Comic Sans MS;
         width: 90px;
         height: 25px;
         border:1px solid #000;
         background-color: #c0c1bd;
         position:absolute;
         left:226px;
         top:151px;
         font-size: 12px;
     }
        </style>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form>
        <div id="div1"> Rice <br>Tuna <br>Bread</div>
        <input id="btn1" type="submit" value="Add">
        <input id="btn2" type="submit" value="Remove">
        <input id="btn3" type="submit" value="Display">
        </form>
    </body>
</html>
